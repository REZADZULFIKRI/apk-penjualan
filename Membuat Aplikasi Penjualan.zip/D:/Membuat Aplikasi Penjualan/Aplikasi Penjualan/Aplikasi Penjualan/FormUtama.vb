﻿Public Class FormUtama
    End Sub
    Private Sub LoginToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginToolStripMenuItem.Click

    End Sub

    Private Sub KeluarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeluarToolStripMenuItem.Click
        Dim konfirmasi = MsgBox("Anda yakin akan keluar aplikasi?",
                                MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Keluar?")
        If konfirmasi = DialogResult.Yes Then
            End
        End If
    End Sub

    Private Sub InfoAplikasiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InfoAplikasiToolStripMenuItem.Click
        Dim AboutBox = New AboutBox
        AboutBox.MdiParent = Me
        AboutBox.Show()
    End Sub

    Private Sub FormUtama_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PelangganToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PelangganToolStripMenuItem.Click

    End Sub
End Class
